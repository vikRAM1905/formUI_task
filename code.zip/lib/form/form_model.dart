class FormModel {
  String? leadId;
  String? leadName;
  String? contact;
  String? region;
  String? address;
  String? type;
  FormModel({
    this.leadId,
    this.leadName,
    this.contact,
    this.region,
    this.address,
    this.type,
  });
}
